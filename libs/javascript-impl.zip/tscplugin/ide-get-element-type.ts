import * as tsModule from "tsserverlibrary"

export function getElementType(ts: typeof tsModule,
                               projectService: tsModule.server.ProjectService,
                               request: tsModule.server.protocol.Request){
  let fileName = ts.server.toNormalizedPath(request.arguments.file)
  let project = projectService.getDefaultProjectForFile(fileName, true)
  if (!project) {
    return undefined
  }

  // see getQuickInfoAtPosition
  let program = project.getLanguageService().getProgram();
  if (!program) {
    return undefined
  }
  const sourceFile = program.getSourceFile(fileName);
  if (!sourceFile) {
    return undefined
  }
  let positionStart = ts.getPositionOfLineAndCharacter(sourceFile, request.arguments.startLine - 1, request.arguments.startOffset - 1)
  let positionEnd = ts.getPositionOfLineAndCharacter(sourceFile, request.arguments.endLine - 1, request.arguments.endOffset - 1)
  let node: tsModule.Node = (ts as any).getTokenAtPosition(sourceFile, positionStart);
  while (node && node.getEnd() < positionEnd) {
    node = node.parent;
  }
  if (!node || node === sourceFile) {
    return undefined;
  }

  const typeChecker = program.getTypeChecker();
  let type = typeChecker.getTypeAtLocation(node);
  let prepared = prepareObjectForSend(type, new Map(), [0])

  return {responseRequired: true, response: prepared}
}


function prepareObjectForSend(obj: any, visited: Map<any, number>, nextId: Array<number>): any {
  if (Array.isArray(obj)) {
    return obj.map(e => prepareObjectForSend(e, visited, nextId))
  }
  if (typeof obj == "object") {
    let id = nextId[0]++
    visited.set(obj, id);
    obj.ideObjectId = id;
    let constructor = obj.constructor
    if (constructor) {
      obj.ideObjectType = constructor.name
    }
    const entries: [string, any][] = objectEntries(obj)
      .filter(([key, _]) =>
        key == "ideObjectId" || key == "ideObjectType" ? true :
        constructor.name == "NodeObject" ? key == "pos" || key == "end" || key == "parent" || key == "kind" :
        constructor.name == "SourceFileObject" ? key == "fileName" || key == "kind" :
        true
      )
      .map(([key, value]) => {
        let subTypeId = visited.get(value)
        if (subTypeId) {
          value = {
            ideObjectIdRef: subTypeId
          };
        }
        else {
          value = prepareObjectForSend(value, visited, nextId)
        }
        return [key, value]
      });
    return objectFromEntries(entries)
  }
  return obj;
}

const objectEntries: (obj: any) => [string, any][] =
  (Object as any).entries ||
  ((obj) => Object.keys(obj).map(k => [k, obj[k]]))

const objectFromEntries: (entries: [string, any][]) => any =
  (Object as any).fromEntries ||
  ((entries) => Array.from(entries).reduce((acc, [ key, val ]) => Object.assign(acc, { [key]: val }), {}))

