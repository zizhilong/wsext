/**
 * The plugin is intended to override and/or extend some behaviour of ts service,
 * please before implementing custom logic here, first consider to implement logic based on tsserver standard api.
 */

import type tsModule from "typescript/lib/tsserverlibrary";
import {getElementType} from "./ide-get-element-type";

const openExternalProjectExCommand = "ideOpenExternalProject";
const projectInfoExCommand = "ideProjectInfo";
const emitFileExCommand = "ideCompileOnSaveEmitFile";
const getElementTypeCommand = "ideGetElementType";

let addedCommands = false;

interface IDEGetProjectsInfo {
  projectName: string
  fileInfos: IDEGetProjectsFileInfo[]
}

interface IDEGetProjectsFileInfo {
  fileName: string,
  isOpen: boolean,
  isExternal: boolean
}

const init: tsModule.server.PluginModuleFactory = ((modules: {
  typescript: typeof tsModule
}) => {
  const ts = modules.typescript;

  let tsVersion = parseNumbersInVersion(ts.version)

  function addNewHandlers(info: tsModule.server.PluginCreateInfo) {
    let projectService = info.project.projectService;
    projectService.logger.info("Called handler processing");

    let session = info.session;
    if (session == undefined) {
      projectService.logger.info("There is no session in info.");
      return;
    }
    if (session.addProtocolHandler == undefined) {
      projectService.logger.info("There is no add method.");
      return;
    }

    if (!isVersionMoreOrEqual(tsVersion, 5)) {
      projectService.logger.info("Skip adding handlers for old version: " + ts.version);
      return;
    }

    session.addProtocolHandler(openExternalProjectExCommand, openExternalProjectHandler.bind(null, ts, projectService));
    session.addProtocolHandler(projectInfoExCommand, projectInfoHandler.bind(null, ts, projectService));
    session.addProtocolHandler(emitFileExCommand, emitFileHandler.bind(null, ts, projectService));
    session.addProtocolHandler(getElementTypeCommand, getElementTypeCommandHandler.bind(null, ts, projectService));

    projectService.logger.info("IDE specific commands are successfully added.");
  }

  function create(info: tsModule.server.PluginCreateInfo) {
    if (addedCommands) return info.languageService;
    addNewHandlers(info);
    addedCommands = true;

    return info.languageService;
  }

  return {create}
});


function openExternalProjectEx(ts: typeof tsModule,
                               projectService: tsModule.server.ProjectService,
                               externalProject: tsModule.server.protocol.ExternalProject) {
  let fileName = externalProject.projectFileName;
  if (fileName == null) return; //nothing to open
  const tsConfigPath = ts.server.toNormalizedPath(fileName);
  if (tsConfigPath.endsWith("/tsconfig.json") ||
    tsConfigPath.endsWith("/jsconfig.json") ||
    !tsConfigPath.endsWith(".json")) {
    projectService.openExternalProject(externalProject);
    return;
  }

  //the code below is kinda hack but so far we don't have a better way to support custom configs
  ((<any>projectService).externalProjectToConfiguredProjectMap).set(externalProject.projectFileName, [tsConfigPath]);
  const project = (<any>projectService).createAndLoadConfiguredProject(
    tsConfigPath, `Creating own configured project in external project: ${externalProject.projectFileName}`);
  project.updateGraph();
  project.addExternalProjectReference();

  return;
}

const getElementTypeCommandHandler = (ts: typeof tsModule,
                                      projectService: tsModule.server.ProjectService,
                                      request: tsModule.server.protocol.Request) => {
  return getElementType(ts, projectService, request) || emptyDoneResponse()
}

const openExternalProjectHandler = (ts: typeof tsModule,
                                    projectService: tsModule.server.ProjectService,
                                    request: tsModule.server.protocol.Request) => {

  let openRequest = request as tsModule.server.protocol.OpenExternalProjectRequest
  let externalProject = openRequest.arguments;
  openExternalProjectEx(ts, projectService, externalProject);

  return {
    response: true,
    responseRequired: true
  };
}

const emitFileHandler = (ts: typeof tsModule,
                         projectService: tsModule.server.ProjectService,
                         request: tsModule.server.protocol.Request) => {
  let host = projectService.host
  let compileRequest = request as tsModule.server.protocol.CompileOnSaveEmitFileRequest;
  let args = compileRequest.arguments;

  let file = args.file ? ts.server.toNormalizedPath(args.file) : undefined;
  let projectFileName = args.projectFileName;

  if (file == null) {
    projectService.logger.info("There is no file to compile: " + projectFileName);
    return {
      response: {
        emitSkipped: true,
        diagnostics: []
      },
      responseRequired: true
    };
  }

  let diagnostics: tsModule.server.protocol.Diagnostic[] = [];
  let generatedFiles: string[] = [];
  let processedFiles: string[] = [];
  let result = {
    emitSkipped: false,
    generatedFiles,
    processedFiles,
    diagnostics: [
      {
        file,
        diagnostics: diagnostics
      }
    ]
  }

  let project = projectFileName ?
    projectService.findProject(projectFileName) :
    projectService.getDefaultProjectForFile(file, false);

  let openedProject = false;
  if (project == null) {
    let fileToOpen = projectFileName ? projectFileName : file!
    openExternalProjectEx(ts, projectService, {
      options: {},
      projectFileName: fileToOpen,
      rootFiles: [{fileName: fileToOpen}]
    });
    openedProject = true;
    project = projectService.findProject(fileToOpen);
  }

  if (project != null) {
    let scriptInfo = project.getScriptInfo(file);
    if (scriptInfo) {
      let result = project.emitFile(scriptInfo,
                                    (path, data, writeByteOrderMark) => {
                                      generatedFiles.push(path);
                                      return host.writeFile(path, data, writeByteOrderMark)
                                    });
      result.emitSkipped = result.emitSkipped;
      if (args.richResponse) {
        let resultDiagnostics: tsModule.Diagnostic[] = [];
        let languageService = project.getLanguageService();
        resultDiagnostics.push(...languageService.getSemanticDiagnostics(file));
        resultDiagnostics.push(...languageService.getSyntacticDiagnostics(file));
        resultDiagnostics.push(...result.diagnostics);
        diagnostics.push(...resultDiagnostics.map(el => formatDiagnosticToProtocol(ts, el, true)));
      }

      if (result.emitSkipped) {
        //no emitted -> reset info
        generatedFiles.length = 0;
      }
    }
    else {
      projectService.logger.info(`There is no script info. File ${file}, project ${projectFileName}`);
    }
  }
  else {
    projectService.logger.info(`There is no project. File ${file}, project ${projectFileName}`);
  }

  if (openedProject) {
    //do not close for perf reason
    // projectService.closeExternalProject(projectFileName);
  }

  return {
    response: result,
    responseRequired: true
  };
}

const projectInfoHandler = (_ts: typeof tsModule,
                            projectService: tsModule.server.ProjectService,
                            _request: tsModule.server.protocol.Request) => {
  let infos: IDEGetProjectsInfo[] = []

  let configuredProjects = projectService.configuredProjects;

  configuredProjects.forEach((configuredProject) => {
    addProjectInfo(configuredProject, infos);
  })

  for (let inferredProject of projectService.inferredProjects) {
    addProjectInfo(inferredProject, infos);
  }

  for (let externalProject of projectService.externalProjects) {
    addProjectInfo(externalProject, infos);
  }

  return {
    responseRequired: true,
    response: infos
  }
};

function addProjectInfo(project: tsModule.server.Project, infos: IDEGetProjectsInfo[]) {
  let name = project.getProjectName();
  let regularFileInfos: IDEGetProjectsFileInfo[] = project.getFileNames(false).map(el => {
    let info = project.getScriptInfo(el);

    return {
      fileName: el,
      isOpen: !!info && info.isScriptOpen(),
      isExternal: false
    }
  })


  let externalFileInfos: IDEGetProjectsFileInfo[] = []
  if (project.getExternalFiles) {
    externalFileInfos = project.getExternalFiles().map(el => {
      let info = project.getScriptInfo(el);

      return {
        fileName: el,
        isOpen: !!info && info.isScriptOpen(),
        isExternal: true
      }
    })
  }

  infos.push({
               projectName: name,
               fileInfos: regularFileInfos.concat(externalFileInfos)
             })
}


function parseNumbersInVersion(version: string): number[] {
  let result: number[] = [];
  let versions = version.split(".");
  for (version of versions) {
    if (!version) break;
    let currentNumber = Number(version)
    if (currentNumber == null || isNaN(currentNumber)) break;
    result = result.concat(currentNumber);
  }
  return result;
}

function diagnosticCategoryName(ts: typeof tsModule,
                                d: {
                                  category: tsModule.DiagnosticCategory
                                }, lowerCase = true): string {
  const name = ts.DiagnosticCategory[d.category];
  return lowerCase ? name.toLowerCase() : name;
}

function isVersionMoreOrEqual(version: number[], ...expected: number[]) {
  for (let i = 0; i < expected.length; i++) {
    let expectedNumber = expected[i];
    let currentNumber = version.length > i ? version[i] : 0;
    if (currentNumber < expectedNumber) return false;
    if (currentNumber > expectedNumber) return true;
  }

  return version.length >= expected.length;
}

function formatDiagnosticToProtocol(ts: typeof tsModule, diag: tsModule.Diagnostic, includeFileName: boolean)
  : tsModule.server.protocol.Diagnostic | tsModule.server.protocol.DiagnosticWithFileName {
  const start = (diag.file && convertToLocation(ts.getLineAndCharacterOfPosition(diag.file, diag.start!)))!;
  const end = (diag.file && convertToLocation(ts.getLineAndCharacterOfPosition(diag.file, diag.start! + diag.length!)))!;
  const text = ts.flattenDiagnosticMessageText(diag.messageText, "\n");
  const {
    code,
    source
  } = diag;
  const category = diagnosticCategoryName(ts, diag);
  const common = {
    start,
    end,
    text,
    code,
    category,
    reportsUnnecessary: diag.reportsUnnecessary,
    reportsDeprecated: diag.reportsDeprecated,
    source
  };
  return includeFileName
    ? {
      ...common,
      fileName: diag.file && diag.file.fileName
    }
    : common;
}

function prepareTypeForSend(type: any, visited: Map<any, number>, nextId: Array<number>): any {
  if (Array.isArray(type)) {
    return type.map(e => prepareTypeForSend(e, visited, nextId))
  }
  if (typeof type == "object") {
    let id = nextId[0]++
    visited.set(type, id);
    type.ideObjectId = id;
    let constructor = type.constructor
    if (constructor) {
      type.ideObjectType = constructor.name
    }
    delete type.checker;

    const entries = Object.entries(type)
      .filter(([key, value]) => key != "checker" && key != "statements" && key != "nextContainer")
      .map(([key, value]) => {
        let subTypeId = visited.get(value)
        if (subTypeId) {
          value = {
            ideObjectIdRef: subTypeId
          };
        }
        else {
          value = prepareTypeForSend(value, visited, nextId)
        }
        return [key, value]
      });
    return Object.fromEntries(entries)
  }
  return type;
}

function emptyDoneResponse() {
  return {
    responseRequired: true,
    response: null
  }

}

function convertToLocation(lineAndCharacter: tsModule.LineAndCharacter): tsModule.server.protocol.Location {
  return {
    line: lineAndCharacter.line + 1,
    offset: lineAndCharacter.character + 1
  };
}


export = init;