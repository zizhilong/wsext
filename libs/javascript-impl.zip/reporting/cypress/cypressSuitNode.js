"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var suiteNode_1 = require("../core/suiteNode");
var cypressTestNode_1 = require("./cypressTestNode");
var CypressSuitNode = /** @class */ (function (_super) {
    __extends(CypressSuitNode, _super);
    function CypressSuitNode(nativeSuite) {
        var _this = _super.call(this, nativeSuite) || this;
        _this.nativeSuite = nativeSuite;
        _this.isRoot = nativeSuite.root;
        _this.locationInFile = _this.composeLocationHint(nativeSuite.titlePath());
        _this.title = nativeSuite.title;
        _this.suites = nativeSuite.suites.map(function (s) { return new CypressSuitNode(s); });
        _this.tests = nativeSuite.tests.map(function (t) { return new cypressTestNode_1.default(t); });
        return _this;
    }
    Object.defineProperty(CypressSuitNode.prototype, "duration", {
        get: function () {
            return 0;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(CypressSuitNode.prototype, "absoluteFilePath", {
        get: function () {
            var _a;
            return (_a = this.nativeSuite.invocationDetails.absoluteFile) !== null && _a !== void 0 ? _a : "";
        },
        enumerable: false,
        configurable: true
    });
    return CypressSuitNode;
}(suiteNode_1.default));
exports.default = CypressSuitNode;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3lwcmVzc1N1aXROb2RlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vc3JjL2N5cHJlc3MvY3lwcmVzc1N1aXROb2RlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQ0EsK0NBQXlDO0FBQ3pDLHFEQUErQztBQUUvQztJQUE2QyxtQ0FBUztJQWVwRCx5QkFBNkIsV0FBa0I7UUFBL0MsWUFDRSxrQkFBTSxXQUFXLENBQUMsU0FNbkI7UUFQNEIsaUJBQVcsR0FBWCxXQUFXLENBQU87UUFFN0MsS0FBSSxDQUFDLE1BQU0sR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFBO1FBQzlCLEtBQUksQ0FBQyxjQUFjLEdBQUcsS0FBSSxDQUFDLG1CQUFtQixDQUFDLFdBQVcsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFBO1FBQ3ZFLEtBQUksQ0FBQyxLQUFLLEdBQUcsV0FBVyxDQUFDLEtBQUssQ0FBQTtRQUM5QixLQUFJLENBQUMsTUFBTSxHQUFHLFdBQVcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLFVBQUMsQ0FBUSxJQUFLLE9BQUEsSUFBSSxlQUFlLENBQUMsQ0FBQyxDQUFDLEVBQXRCLENBQXNCLENBQUMsQ0FBQTtRQUMxRSxLQUFJLENBQUMsS0FBSyxHQUFHLFdBQVcsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLFVBQUMsQ0FBTyxJQUFLLE9BQUEsSUFBSSx5QkFBZSxDQUFDLENBQUMsQ0FBQyxFQUF0QixDQUFzQixDQUFDLENBQUE7O0lBQ3pFLENBQUM7SUFmRCxzQkFBYSxxQ0FBUTthQUFyQjtZQUNFLE9BQU8sQ0FBQyxDQUFBO1FBQ1YsQ0FBQzs7O09BQUE7SUFFRCxzQkFBYSw2Q0FBZ0I7YUFBN0I7O1lBQ0UsT0FBTyxNQUFBLElBQUksQ0FBQyxXQUFXLENBQUMsaUJBQWlCLENBQUMsWUFBWSxtQ0FBSSxFQUFFLENBQUE7UUFDOUQsQ0FBQzs7O09BQUE7SUFVSCxzQkFBQztBQUFELENBQUMsQUF2QkQsQ0FBNkMsbUJBQVMsR0F1QnJEIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtTdWl0ZSwgVGVzdH0gZnJvbSBcIm1vY2hhXCJcbmltcG9ydCBTdWl0ZU5vZGUgZnJvbSBcIi4uL2NvcmUvc3VpdGVOb2RlXCJcbmltcG9ydCBDeXByZXNzVGVzdE5vZGUgZnJvbSBcIi4vY3lwcmVzc1Rlc3ROb2RlXCJcblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgQ3lwcmVzc1N1aXROb2RlIGV4dGVuZHMgU3VpdGVOb2RlIHtcbiAgb3ZlcnJpZGUgcmVhZG9ubHkgaXNSb290OiBib29sZWFuXG4gIG92ZXJyaWRlIHJlYWRvbmx5IGxvY2F0aW9uSW5GaWxlOiBzdHJpbmdcbiAgb3ZlcnJpZGUgcmVhZG9ubHkgc3VpdGVzOiBDeXByZXNzU3VpdE5vZGVbXVxuICBvdmVycmlkZSByZWFkb25seSB0ZXN0czogQ3lwcmVzc1Rlc3ROb2RlW11cbiAgb3ZlcnJpZGUgcmVhZG9ubHkgdGl0bGU6IHN0cmluZ1xuXG4gIG92ZXJyaWRlIGdldCBkdXJhdGlvbigpOiBudW1iZXIge1xuICAgIHJldHVybiAwXG4gIH1cblxuICBvdmVycmlkZSBnZXQgYWJzb2x1dGVGaWxlUGF0aCgpOiBzdHJpbmcge1xuICAgIHJldHVybiB0aGlzLm5hdGl2ZVN1aXRlLmludm9jYXRpb25EZXRhaWxzLmFic29sdXRlRmlsZSA/PyBcIlwiXG4gIH1cblxuICBjb25zdHJ1Y3Rvcihwcml2YXRlIHJlYWRvbmx5IG5hdGl2ZVN1aXRlOiBTdWl0ZSkge1xuICAgIHN1cGVyKG5hdGl2ZVN1aXRlKVxuICAgIHRoaXMuaXNSb290ID0gbmF0aXZlU3VpdGUucm9vdFxuICAgIHRoaXMubG9jYXRpb25JbkZpbGUgPSB0aGlzLmNvbXBvc2VMb2NhdGlvbkhpbnQobmF0aXZlU3VpdGUudGl0bGVQYXRoKCkpXG4gICAgdGhpcy50aXRsZSA9IG5hdGl2ZVN1aXRlLnRpdGxlXG4gICAgdGhpcy5zdWl0ZXMgPSBuYXRpdmVTdWl0ZS5zdWl0ZXMubWFwKChzOiBTdWl0ZSkgPT4gbmV3IEN5cHJlc3NTdWl0Tm9kZShzKSlcbiAgICB0aGlzLnRlc3RzID0gbmF0aXZlU3VpdGUudGVzdHMubWFwKCh0OiBUZXN0KSA9PiBuZXcgQ3lwcmVzc1Rlc3ROb2RlKHQpKVxuICB9XG59Il19