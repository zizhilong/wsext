"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.teamcityFormatCountMessage = exports.teamcityFormatMessage = void 0;
var testNodeStatus_1 = require("./testNodeStatus");
var reporterUtils_1 = require("./reporterUtils");
function teamcityFormatMessage(message, node, extraProps) {
    if (node === void 0) { node = null; }
    if (extraProps === void 0) { extraProps = ""; }
    var props = extraProps !== "" ? " " + extraProps + " " : "";
    var nodeValues = node ? (" " + node.toKeyValueString()) : "";
    return "##teamcity[".concat(message).concat(props).concat(nodeValues, "]");
}
exports.teamcityFormatMessage = teamcityFormatMessage;
function teamcityFormatCountMessage(count) {
    return "##teamcity[testCount count='".concat(count, "']");
}
exports.teamcityFormatCountMessage = teamcityFormatCountMessage;
var TestEventsHandler = /** @class */ (function () {
    /**
     * @param write Custom `write` function, redefined to write to file for tests
     */
    function TestEventsHandler(write) {
        if (write === void 0) { write = console.log; }
        this.write = write;
        this.nextNodeId = 0;
        this.write = write;
    }
    /**
     * Starts testing and registers all test nodes
     * @param rootSuit - top most suit element i.e. without parent
     */
    TestEventsHandler.prototype.startTesting = function (rootSuit) {
        this.write(teamcityFormatMessage("enteredTheMatrix"));
        this.write(teamcityFormatMessage("testingStarted"));
        var count = this.registerTestNodes(rootSuit, this.nextNodeId++);
        this.write(teamcityFormatCountMessage(count));
    };
    /**
     * @param suite
     * @see {@link com.intellij.execution.testframework.sm.runner.OutputToGeneralTestEventsConverter.MyServiceMessageVisitor#visitTestSuiteStarted visitTestSuiteStarted}
     */
    TestEventsHandler.prototype.startSuite = function (suite) {
        if (suite.status !== testNodeStatus_1.default.NotStarted)
            return;
        if (suite.isRoot)
            return;
        suite.status = testNodeStatus_1.default.Running;
        this.write(teamcityFormatMessage("testSuiteStarted", suite));
    };
    /**
     * @param test
     * @see {@link com.intellij.execution.testframework.sm.runner.OutputToGeneralTestEventsConverter.MyServiceMessageVisitor#visitTestStarted visitTestStarted}
     */
    TestEventsHandler.prototype.startTest = function (test) {
        if (test.status !== testNodeStatus_1.default.NotStarted)
            return;
        test.status = testNodeStatus_1.default.Running;
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-ignore
        this.write(teamcityFormatMessage("testStarted", test));
    };
    TestEventsHandler.prototype.ignoreTest = function (test) {
        if (test.status !== testNodeStatus_1.default.Running)
            return;
        test.status = testNodeStatus_1.default.Finished;
        this.write(teamcityFormatMessage("testIgnored", test, "message='Pending test |'".concat(test.title, "|''")));
    };
    /**
     * @param test
     * @param error - if provided triggers error message, instead of success
     * @see {@link com.intellij.execution.testframework.sm.runner.OutputToGeneralTestEventsConverter.MyServiceMessageVisitor#visitTestFinished visitTestFinished}
     * @see {@link com.intellij.execution.testframework.sm.runner.OutputToGeneralTestEventsConverter.MyServiceMessageVisitor#visitTestFailed visitTestFailed}
     */
    TestEventsHandler.prototype.finishTest = function (test, error) {
        if (error === void 0) { error = null; }
        if (test.status !== testNodeStatus_1.default.Running)
            return;
        test.status = testNodeStatus_1.default.Finished;
        if (error === null) {
            this.write(teamcityFormatMessage("testFinished", test));
        }
        else {
            this.write(teamcityFormatMessage("testFailed", test, "message='".concat(reporterUtils_1.default.escapeAttributeValue(error.message), "' details='").concat(reporterUtils_1.default.escapeAttributeValue(error.stack), "'")));
            // TODO advanced error printing with 'expect' and 'actual' arguments}
        }
    };
    /**
     * @param suite
     * @see {@link com.intellij.execution.testframework.sm.runner.OutputToGeneralTestEventsConverter.MyServiceMessageVisitor#visitTestSuiteFinished visitTestSuiteFinished}
     */
    TestEventsHandler.prototype.finishSuite = function (suite) {
        if (suite.status !== testNodeStatus_1.default.Running)
            return;
        if (suite.isRoot)
            return;
        suite.status = testNodeStatus_1.default.Finished;
        this.write(teamcityFormatMessage("testSuiteFinished", suite));
    };
    TestEventsHandler.prototype.finishTesting = function () {
        this.write(teamcityFormatMessage("testingFinished"));
    };
    /**
     * Builds structure of test nodes as tree
     * @param rootSuite
     * @param parentNodeId
     * @returns number of registered nodes
     * @private
     */
    TestEventsHandler.prototype.registerTestNodes = function (rootSuite, parentNodeId) {
        var _this = this;
        var count = 0;
        if (!rootSuite.isRoot) {
            rootSuite.setUpTestNode(this.nextNodeId++, parentNodeId);
            rootSuite.status = testNodeStatus_1.default.NotStarted;
        }
        var validParentNodeId = rootSuite["nodeId"] === undefined ? parentNodeId : rootSuite["nodeId"];
        rootSuite.tests.forEach(function (test) {
            count++;
            test.setUpTestNode(_this.nextNodeId++, validParentNodeId);
            test.status = testNodeStatus_1.default.NotStarted;
        });
        rootSuite.suites.forEach(function (suite) {
            count += _this.registerTestNodes(suite, validParentNodeId);
        });
        return count;
    };
    return TestEventsHandler;
}());
exports.default = TestEventsHandler;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGVzdEV2ZW50c0hhbmRsZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi9zcmMvY29yZS90ZXN0RXZlbnRzSGFuZGxlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFFQSxtREFBNkM7QUFDN0MsaURBQTJDO0FBYzNDLFNBQWdCLHFCQUFxQixDQUFDLE9BQW9CLEVBQUUsSUFBNEIsRUFBRSxVQUF1QjtJQUFyRCxxQkFBQSxFQUFBLFdBQTRCO0lBQUUsMkJBQUEsRUFBQSxlQUF1QjtJQUMvRyxJQUFNLEtBQUssR0FBRyxVQUFVLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsVUFBVSxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFBO0lBQzdELElBQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFBO0lBQzlELE9BQU8scUJBQWMsT0FBTyxTQUFHLEtBQUssU0FBRyxVQUFVLE1BQUcsQ0FBQTtBQUN0RCxDQUFDO0FBSkQsc0RBSUM7QUFFRCxTQUFnQiwwQkFBMEIsQ0FBQyxLQUFhO0lBQ3RELE9BQU8sc0NBQStCLEtBQUssT0FBSSxDQUFBO0FBQ2pELENBQUM7QUFGRCxnRUFFQztBQUVEO0lBR0U7O09BRUc7SUFDSCwyQkFBK0IsS0FBMEM7UUFBMUMsc0JBQUEsRUFBQSxRQUErQixPQUFPLENBQUMsR0FBRztRQUExQyxVQUFLLEdBQUwsS0FBSyxDQUFxQztRQUxqRSxlQUFVLEdBQUcsQ0FBQyxDQUFDO1FBTXJCLElBQUksQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO0lBQ3JCLENBQUM7SUFFRDs7O09BR0c7SUFDSCx3Q0FBWSxHQUFaLFVBQWEsUUFBbUI7UUFDOUIsSUFBSSxDQUFDLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUE7UUFDckQsSUFBSSxDQUFDLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUE7UUFFbkQsSUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUMsQ0FBQTtRQUNqRSxJQUFJLENBQUMsS0FBSyxDQUFDLDBCQUEwQixDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7SUFDaEQsQ0FBQztJQUVEOzs7T0FHRztJQUNILHNDQUFVLEdBQVYsVUFBVyxLQUFnQjtRQUN6QixJQUFJLEtBQUssQ0FBQyxNQUFNLEtBQUssd0JBQWMsQ0FBQyxVQUFVO1lBQUUsT0FBTztRQUN2RCxJQUFJLEtBQUssQ0FBQyxNQUFNO1lBQUUsT0FBTztRQUV6QixLQUFLLENBQUMsTUFBTSxHQUFHLHdCQUFjLENBQUMsT0FBTyxDQUFBO1FBRXJDLElBQUksQ0FBQyxLQUFLLENBQUMscUJBQXFCLENBQUMsa0JBQWtCLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQTtJQUM5RCxDQUFDO0lBRUQ7OztPQUdHO0lBQ0gscUNBQVMsR0FBVCxVQUFVLElBQWM7UUFDdEIsSUFBSSxJQUFJLENBQUMsTUFBTSxLQUFLLHdCQUFjLENBQUMsVUFBVTtZQUFFLE9BQU87UUFDdEQsSUFBSSxDQUFDLE1BQU0sR0FBRyx3QkFBYyxDQUFDLE9BQU8sQ0FBQTtRQUNwQyw2REFBNkQ7UUFDN0QsYUFBYTtRQUNiLElBQUksQ0FBQyxLQUFLLENBQUMscUJBQXFCLENBQUMsYUFBYSxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUE7SUFDeEQsQ0FBQztJQUVELHNDQUFVLEdBQVYsVUFBVyxJQUFjO1FBQ3ZCLElBQUksSUFBSSxDQUFDLE1BQU0sS0FBSyx3QkFBYyxDQUFDLE9BQU87WUFBRSxPQUFPO1FBQ25ELElBQUksQ0FBQyxNQUFNLEdBQUcsd0JBQWMsQ0FBQyxRQUFRLENBQUE7UUFDckMsSUFBSSxDQUFDLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQyxhQUFhLEVBQUUsSUFBSSxFQUFFLGtDQUEyQixJQUFJLENBQUMsS0FBSyxRQUFLLENBQUMsQ0FBQyxDQUFBO0lBQ3BHLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILHNDQUFVLEdBQVYsVUFBVyxJQUFjLEVBQUUsS0FBbUI7UUFBbkIsc0JBQUEsRUFBQSxZQUFtQjtRQUM1QyxJQUFJLElBQUksQ0FBQyxNQUFNLEtBQUssd0JBQWMsQ0FBQyxPQUFPO1lBQUUsT0FBTztRQUNuRCxJQUFJLENBQUMsTUFBTSxHQUFHLHdCQUFjLENBQUMsUUFBUSxDQUFBO1FBQ3JDLElBQUksS0FBSyxLQUFLLElBQUksRUFBRTtZQUNsQixJQUFJLENBQUMsS0FBSyxDQUFDLHFCQUFxQixDQUFDLGNBQWMsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFBO1NBQ3hEO2FBQ0k7WUFDSCxJQUFJLENBQUMsS0FBSyxDQUFDLHFCQUFxQixDQUFDLFlBQVksRUFBRSxJQUFJLEVBQUUsbUJBQVksdUJBQWEsQ0FBQyxvQkFBb0IsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLHdCQUFjLHVCQUFhLENBQUMsb0JBQW9CLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFHLENBQUMsQ0FBQyxDQUFBO1lBQ3BMLHFFQUFxRTtTQUN0RTtJQUNILENBQUM7SUFFRDs7O09BR0c7SUFDSCx1Q0FBVyxHQUFYLFVBQVksS0FBZ0I7UUFDMUIsSUFBSSxLQUFLLENBQUMsTUFBTSxLQUFLLHdCQUFjLENBQUMsT0FBTztZQUN6QyxPQUFPO1FBRVQsSUFBSSxLQUFLLENBQUMsTUFBTTtZQUNkLE9BQU87UUFFVCxLQUFLLENBQUMsTUFBTSxHQUFHLHdCQUFjLENBQUMsUUFBUSxDQUFBO1FBQ3RDLElBQUksQ0FBQyxLQUFLLENBQUMscUJBQXFCLENBQUMsbUJBQW1CLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQTtJQUMvRCxDQUFDO0lBRUQseUNBQWEsR0FBYjtRQUNFLElBQUksQ0FBQyxLQUFLLENBQUMscUJBQXFCLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFBO0lBQ3RELENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSyw2Q0FBaUIsR0FBekIsVUFBMEIsU0FBb0IsRUFBRSxZQUFvQjtRQUFwRSxpQkFrQkM7UUFqQkMsSUFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDO1FBQ2QsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEVBQUU7WUFDckIsU0FBUyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLEVBQUUsWUFBWSxDQUFDLENBQUE7WUFDeEQsU0FBUyxDQUFDLE1BQU0sR0FBRyx3QkFBYyxDQUFDLFVBQVUsQ0FBQTtTQUM3QztRQUVELElBQU0saUJBQWlCLEdBQVcsU0FBUyxDQUFDLFFBQVEsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUE7UUFFeEcsU0FBUyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsVUFBQyxJQUFJO1lBQzNCLEtBQUssRUFBRSxDQUFBO1lBQ1AsSUFBSSxDQUFDLGFBQWEsQ0FBQyxLQUFJLENBQUMsVUFBVSxFQUFFLEVBQUUsaUJBQWlCLENBQUMsQ0FBQTtZQUN4RCxJQUFJLENBQUMsTUFBTSxHQUFHLHdCQUFjLENBQUMsVUFBVSxDQUFBO1FBQ3pDLENBQUMsQ0FBQyxDQUFDO1FBQ0gsU0FBUyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsVUFBQyxLQUFLO1lBQzdCLEtBQUssSUFBSSxLQUFJLENBQUMsaUJBQWlCLENBQUMsS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUE7UUFDM0QsQ0FBQyxDQUFDLENBQUM7UUFDSCxPQUFPLEtBQUssQ0FBQTtJQUNkLENBQUM7SUFDSCx3QkFBQztBQUFELENBQUMsQUFwSEQsSUFvSEMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgU3VpdGVOb2RlIGZyb20gXCIuL3N1aXRlTm9kZVwiXG5pbXBvcnQgVGVzdE5vZGUgZnJvbSBcIi4vdGVzdE5vZGVcIlxuaW1wb3J0IFRlc3ROb2RlU3RhdHVzIGZyb20gXCIuL3Rlc3ROb2RlU3RhdHVzXCJcbmltcG9ydCBSZXBvcnRlclV0aWxzIGZyb20gXCIuL3JlcG9ydGVyVXRpbHNcIlxuXG5leHBvcnQgdHlwZSBUZXN0TWVzc2FnZSA9IFwiZW50ZXJlZFRoZU1hdHJpeFwiXG4gIHwgXCJ0ZXN0aW5nU3RhcnRlZFwiXG4gIHwgXCJ0ZXN0U3VpdGVTdGFydGVkXCJcbiAgfCBcInRlc3RTdGFydGVkXCJcbiAgfCBcInRlc3RTdGVwU3RhcnRlZFwiXG4gIHwgXCJ0ZXN0U3RlcEZpbmlzaGVkXCJcbiAgfCBcInRlc3RGaW5pc2hlZFwiXG4gIHwgXCJ0ZXN0RmFpbGVkXCJcbiAgfCBcInRlc3RJZ25vcmVkXCJcbiAgfCBcInRlc3RTdWl0ZUZpbmlzaGVkXCJcbiAgfCBcInRlc3RpbmdGaW5pc2hlZFwiXG5cbmV4cG9ydCBmdW5jdGlvbiB0ZWFtY2l0eUZvcm1hdE1lc3NhZ2UobWVzc2FnZTogVGVzdE1lc3NhZ2UsIG5vZGU6IFRlc3ROb2RlIHwgbnVsbCA9IG51bGwsIGV4dHJhUHJvcHM6IHN0cmluZyA9IFwiXCIpIHtcbiAgY29uc3QgcHJvcHMgPSBleHRyYVByb3BzICE9PSBcIlwiID8gXCIgXCIgKyBleHRyYVByb3BzICsgXCIgXCIgOiBcIlwiXG4gIGNvbnN0IG5vZGVWYWx1ZXMgPSBub2RlID8gKFwiIFwiICsgbm9kZS50b0tleVZhbHVlU3RyaW5nKCkpIDogXCJcIlxuICByZXR1cm4gYCMjdGVhbWNpdHlbJHttZXNzYWdlfSR7cHJvcHN9JHtub2RlVmFsdWVzfV1gXG59XG5cbmV4cG9ydCBmdW5jdGlvbiB0ZWFtY2l0eUZvcm1hdENvdW50TWVzc2FnZShjb3VudDogbnVtYmVyKSB7XG4gIHJldHVybiBgIyN0ZWFtY2l0eVt0ZXN0Q291bnQgY291bnQ9JyR7Y291bnR9J11gXG59XG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFRlc3RFdmVudHNIYW5kbGVyIHtcbiAgcHJpdmF0ZSBuZXh0Tm9kZUlkID0gMDtcblxuICAvKipcbiAgICogQHBhcmFtIHdyaXRlIEN1c3RvbSBgd3JpdGVgIGZ1bmN0aW9uLCByZWRlZmluZWQgdG8gd3JpdGUgdG8gZmlsZSBmb3IgdGVzdHNcbiAgICovXG4gIGNvbnN0cnVjdG9yKHByb3RlY3RlZCByZWFkb25seSB3cml0ZTogKHN0cjogc3RyaW5nKSA9PiB2b2lkID0gY29uc29sZS5sb2cpIHtcbiAgICB0aGlzLndyaXRlID0gd3JpdGU7XG4gIH1cblxuICAvKipcbiAgICogU3RhcnRzIHRlc3RpbmcgYW5kIHJlZ2lzdGVycyBhbGwgdGVzdCBub2Rlc1xuICAgKiBAcGFyYW0gcm9vdFN1aXQgLSB0b3AgbW9zdCBzdWl0IGVsZW1lbnQgaS5lLiB3aXRob3V0IHBhcmVudFxuICAgKi9cbiAgc3RhcnRUZXN0aW5nKHJvb3RTdWl0OiBTdWl0ZU5vZGUpOiB2b2lkIHtcbiAgICB0aGlzLndyaXRlKHRlYW1jaXR5Rm9ybWF0TWVzc2FnZShcImVudGVyZWRUaGVNYXRyaXhcIikpXG4gICAgdGhpcy53cml0ZSh0ZWFtY2l0eUZvcm1hdE1lc3NhZ2UoXCJ0ZXN0aW5nU3RhcnRlZFwiKSlcblxuICAgIGNvbnN0IGNvdW50ID0gdGhpcy5yZWdpc3RlclRlc3ROb2Rlcyhyb290U3VpdCwgdGhpcy5uZXh0Tm9kZUlkKyspXG4gICAgdGhpcy53cml0ZSh0ZWFtY2l0eUZvcm1hdENvdW50TWVzc2FnZShjb3VudCkpO1xuICB9XG5cbiAgLyoqXG4gICAqIEBwYXJhbSBzdWl0ZVxuICAgKiBAc2VlIHtAbGluayBjb20uaW50ZWxsaWouZXhlY3V0aW9uLnRlc3RmcmFtZXdvcmsuc20ucnVubmVyLk91dHB1dFRvR2VuZXJhbFRlc3RFdmVudHNDb252ZXJ0ZXIuTXlTZXJ2aWNlTWVzc2FnZVZpc2l0b3IjdmlzaXRUZXN0U3VpdGVTdGFydGVkIHZpc2l0VGVzdFN1aXRlU3RhcnRlZH1cbiAgICovXG4gIHN0YXJ0U3VpdGUoc3VpdGU6IFN1aXRlTm9kZSk6IHZvaWQge1xuICAgIGlmIChzdWl0ZS5zdGF0dXMgIT09IFRlc3ROb2RlU3RhdHVzLk5vdFN0YXJ0ZWQpIHJldHVybjtcbiAgICBpZiAoc3VpdGUuaXNSb290KSByZXR1cm47XG5cbiAgICBzdWl0ZS5zdGF0dXMgPSBUZXN0Tm9kZVN0YXR1cy5SdW5uaW5nXG5cbiAgICB0aGlzLndyaXRlKHRlYW1jaXR5Rm9ybWF0TWVzc2FnZShcInRlc3RTdWl0ZVN0YXJ0ZWRcIiwgc3VpdGUpKVxuICB9XG5cbiAgLyoqXG4gICAqIEBwYXJhbSB0ZXN0XG4gICAqIEBzZWUge0BsaW5rIGNvbS5pbnRlbGxpai5leGVjdXRpb24udGVzdGZyYW1ld29yay5zbS5ydW5uZXIuT3V0cHV0VG9HZW5lcmFsVGVzdEV2ZW50c0NvbnZlcnRlci5NeVNlcnZpY2VNZXNzYWdlVmlzaXRvciN2aXNpdFRlc3RTdGFydGVkIHZpc2l0VGVzdFN0YXJ0ZWR9XG4gICAqL1xuICBzdGFydFRlc3QodGVzdDogVGVzdE5vZGUpOiB2b2lkIHtcbiAgICBpZiAodGVzdC5zdGF0dXMgIT09IFRlc3ROb2RlU3RhdHVzLk5vdFN0YXJ0ZWQpIHJldHVybjtcbiAgICB0ZXN0LnN0YXR1cyA9IFRlc3ROb2RlU3RhdHVzLlJ1bm5pbmdcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L2Jhbi10cy1jb21tZW50XG4gICAgLy8gQHRzLWlnbm9yZVxuICAgIHRoaXMud3JpdGUodGVhbWNpdHlGb3JtYXRNZXNzYWdlKFwidGVzdFN0YXJ0ZWRcIiwgdGVzdCkpXG4gIH1cblxuICBpZ25vcmVUZXN0KHRlc3Q6IFRlc3ROb2RlKTogdm9pZCB7XG4gICAgaWYgKHRlc3Quc3RhdHVzICE9PSBUZXN0Tm9kZVN0YXR1cy5SdW5uaW5nKSByZXR1cm47XG4gICAgdGVzdC5zdGF0dXMgPSBUZXN0Tm9kZVN0YXR1cy5GaW5pc2hlZFxuICAgIHRoaXMud3JpdGUodGVhbWNpdHlGb3JtYXRNZXNzYWdlKFwidGVzdElnbm9yZWRcIiwgdGVzdCwgYG1lc3NhZ2U9J1BlbmRpbmcgdGVzdCB8JyR7dGVzdC50aXRsZX18JydgKSlcbiAgfVxuXG4gIC8qKlxuICAgKiBAcGFyYW0gdGVzdFxuICAgKiBAcGFyYW0gZXJyb3IgLSBpZiBwcm92aWRlZCB0cmlnZ2VycyBlcnJvciBtZXNzYWdlLCBpbnN0ZWFkIG9mIHN1Y2Nlc3NcbiAgICogQHNlZSB7QGxpbmsgY29tLmludGVsbGlqLmV4ZWN1dGlvbi50ZXN0ZnJhbWV3b3JrLnNtLnJ1bm5lci5PdXRwdXRUb0dlbmVyYWxUZXN0RXZlbnRzQ29udmVydGVyLk15U2VydmljZU1lc3NhZ2VWaXNpdG9yI3Zpc2l0VGVzdEZpbmlzaGVkIHZpc2l0VGVzdEZpbmlzaGVkfVxuICAgKiBAc2VlIHtAbGluayBjb20uaW50ZWxsaWouZXhlY3V0aW9uLnRlc3RmcmFtZXdvcmsuc20ucnVubmVyLk91dHB1dFRvR2VuZXJhbFRlc3RFdmVudHNDb252ZXJ0ZXIuTXlTZXJ2aWNlTWVzc2FnZVZpc2l0b3IjdmlzaXRUZXN0RmFpbGVkIHZpc2l0VGVzdEZhaWxlZH1cbiAgICovXG4gIGZpbmlzaFRlc3QodGVzdDogVGVzdE5vZGUsIGVycm9yOiBFcnJvciA9IG51bGwpOiB2b2lkIHtcbiAgICBpZiAodGVzdC5zdGF0dXMgIT09IFRlc3ROb2RlU3RhdHVzLlJ1bm5pbmcpIHJldHVybjtcbiAgICB0ZXN0LnN0YXR1cyA9IFRlc3ROb2RlU3RhdHVzLkZpbmlzaGVkXG4gICAgaWYgKGVycm9yID09PSBudWxsKSB7XG4gICAgICB0aGlzLndyaXRlKHRlYW1jaXR5Rm9ybWF0TWVzc2FnZShcInRlc3RGaW5pc2hlZFwiLCB0ZXN0KSlcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICB0aGlzLndyaXRlKHRlYW1jaXR5Rm9ybWF0TWVzc2FnZShcInRlc3RGYWlsZWRcIiwgdGVzdCwgYG1lc3NhZ2U9JyR7UmVwb3J0ZXJVdGlscy5lc2NhcGVBdHRyaWJ1dGVWYWx1ZShlcnJvci5tZXNzYWdlKX0nIGRldGFpbHM9JyR7UmVwb3J0ZXJVdGlscy5lc2NhcGVBdHRyaWJ1dGVWYWx1ZShlcnJvci5zdGFjayl9J2ApKVxuICAgICAgLy8gVE9ETyBhZHZhbmNlZCBlcnJvciBwcmludGluZyB3aXRoICdleHBlY3QnIGFuZCAnYWN0dWFsJyBhcmd1bWVudHN9XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIEBwYXJhbSBzdWl0ZVxuICAgKiBAc2VlIHtAbGluayBjb20uaW50ZWxsaWouZXhlY3V0aW9uLnRlc3RmcmFtZXdvcmsuc20ucnVubmVyLk91dHB1dFRvR2VuZXJhbFRlc3RFdmVudHNDb252ZXJ0ZXIuTXlTZXJ2aWNlTWVzc2FnZVZpc2l0b3IjdmlzaXRUZXN0U3VpdGVGaW5pc2hlZCB2aXNpdFRlc3RTdWl0ZUZpbmlzaGVkfVxuICAgKi9cbiAgZmluaXNoU3VpdGUoc3VpdGU6IFN1aXRlTm9kZSk6IHZvaWQge1xuICAgIGlmIChzdWl0ZS5zdGF0dXMgIT09IFRlc3ROb2RlU3RhdHVzLlJ1bm5pbmcpXG4gICAgICByZXR1cm47XG5cbiAgICBpZiAoc3VpdGUuaXNSb290KVxuICAgICAgcmV0dXJuO1xuXG4gICAgc3VpdGUuc3RhdHVzID0gVGVzdE5vZGVTdGF0dXMuRmluaXNoZWRcbiAgICB0aGlzLndyaXRlKHRlYW1jaXR5Rm9ybWF0TWVzc2FnZShcInRlc3RTdWl0ZUZpbmlzaGVkXCIsIHN1aXRlKSlcbiAgfVxuXG4gIGZpbmlzaFRlc3RpbmcoKTogdm9pZCB7XG4gICAgdGhpcy53cml0ZSh0ZWFtY2l0eUZvcm1hdE1lc3NhZ2UoXCJ0ZXN0aW5nRmluaXNoZWRcIikpXG4gIH1cblxuICAvKipcbiAgICogQnVpbGRzIHN0cnVjdHVyZSBvZiB0ZXN0IG5vZGVzIGFzIHRyZWVcbiAgICogQHBhcmFtIHJvb3RTdWl0ZVxuICAgKiBAcGFyYW0gcGFyZW50Tm9kZUlkXG4gICAqIEByZXR1cm5zIG51bWJlciBvZiByZWdpc3RlcmVkIG5vZGVzXG4gICAqIEBwcml2YXRlXG4gICAqL1xuICBwcml2YXRlIHJlZ2lzdGVyVGVzdE5vZGVzKHJvb3RTdWl0ZTogU3VpdGVOb2RlLCBwYXJlbnROb2RlSWQ6IG51bWJlcik6IG51bWJlciB7XG4gICAgbGV0IGNvdW50ID0gMDtcbiAgICBpZiAoIXJvb3RTdWl0ZS5pc1Jvb3QpIHtcbiAgICAgIHJvb3RTdWl0ZS5zZXRVcFRlc3ROb2RlKHRoaXMubmV4dE5vZGVJZCsrLCBwYXJlbnROb2RlSWQpXG4gICAgICByb290U3VpdGUuc3RhdHVzID0gVGVzdE5vZGVTdGF0dXMuTm90U3RhcnRlZFxuICAgIH1cblxuICAgIGNvbnN0IHZhbGlkUGFyZW50Tm9kZUlkOiBudW1iZXIgPSByb290U3VpdGVbXCJub2RlSWRcIl0gPT09IHVuZGVmaW5lZCA/IHBhcmVudE5vZGVJZCA6IHJvb3RTdWl0ZVtcIm5vZGVJZFwiXVxuXG4gICAgcm9vdFN1aXRlLnRlc3RzLmZvckVhY2goKHRlc3QpID0+IHtcbiAgICAgIGNvdW50KytcbiAgICAgIHRlc3Quc2V0VXBUZXN0Tm9kZSh0aGlzLm5leHROb2RlSWQrKywgdmFsaWRQYXJlbnROb2RlSWQpXG4gICAgICB0ZXN0LnN0YXR1cyA9IFRlc3ROb2RlU3RhdHVzLk5vdFN0YXJ0ZWRcbiAgICB9KTtcbiAgICByb290U3VpdGUuc3VpdGVzLmZvckVhY2goKHN1aXRlKSA9PiB7XG4gICAgICBjb3VudCArPSB0aGlzLnJlZ2lzdGVyVGVzdE5vZGVzKHN1aXRlLCB2YWxpZFBhcmVudE5vZGVJZClcbiAgICB9KTtcbiAgICByZXR1cm4gY291bnRcbiAgfVxufSJdfQ==