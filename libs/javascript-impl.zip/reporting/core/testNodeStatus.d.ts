declare enum TestNodeStatus {
    NotStarted = 0,
    Running = 1,
    Finished = 2
}
export default TestNodeStatus;
