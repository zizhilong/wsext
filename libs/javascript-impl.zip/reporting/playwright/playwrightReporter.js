"use strict";
var playwrightSuitNode_1 = require("./playwrightSuitNode");
var playwrightTestNode_1 = require("./playwrightTestNode");
var playwrightTestStructure_1 = require("./playwrightTestStructure");
var testNodeStatus_1 = require("../core/testNodeStatus");
var ansiRegexPattern = [
    '[\\u001B\\u009B][[\\]()#;?]*(?:(?:(?:(?:;[-a-zA-Z\\d\\/#&.:=?%@~_]+)*|[a-zA-Z\\d]+(?:;[-a-zA-Z\\d\\/#&.:=?%@~_]*)*)?\\u0007)',
    '(?:(?:\\d{1,4}(?:;\\d{0,4})*)?[\\dA-PR-TZcf-ntqry=><~]))'
].join('|');
var ansiRegex = new RegExp(ansiRegexPattern, 'g');
var PlaywrightJBReporter = /** @class */ (function () {
    function PlaywrightJBReporter() {
        this.testStructure = new playwrightTestStructure_1.default();
        this.globalErrors = [];
    }
    PlaywrightJBReporter.prototype.printsToStdio = function () {
        return true;
    };
    PlaywrightJBReporter.prototype.onBegin = function (config, suite) {
        this.testStructure.startTesting(new playwrightSuitNode_1.default(suite));
        // root
        this.testStructure.startSuite(new playwrightSuitNode_1.default(suite));
    };
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    PlaywrightJBReporter.prototype.onTestBegin = function (test, result) {
        var _this = this;
        var suite = new playwrightSuitNode_1.default(test.parent);
        var suitesToStart = [];
        while (suite !== undefined && suite.status === testNodeStatus_1.default.NotStarted) {
            suitesToStart.push(suite);
            if (suite.nativeSuite.parent === undefined)
                suite = undefined;
            else
                suite = new playwrightSuitNode_1.default(suite.nativeSuite.parent);
        }
        suitesToStart.reverse().forEach(function (suite) {
            _this.testStructure.startSuite(suite);
        });
        this.testStructure.startTest(new playwrightTestNode_1.default(test));
        if (test.expectedStatus == 'skipped') {
            this.testStructure.ignoreTest(new playwrightTestNode_1.default(test));
        }
    };
    PlaywrightJBReporter.prototype.onStepBegin = function (test, result, step) {
        this.testStructure.startStep(step);
    };
    PlaywrightJBReporter.prototype.onStepEnd = function (test, result, step) {
        this.testStructure.finishStep(step);
    };
    PlaywrightJBReporter.prototype.onTestEnd = function (test, result) {
        // If the test status is interrupted, don't have to finish test in structure, it will be marked as interrupted by default
        if (result.status == "interrupted")
            return;
        var error = (test.outcome() == "unexpected") ? this.buildError(result) : null;
        this.testStructure.finishTest(new playwrightTestNode_1.default(test), error);
        var suite = new playwrightSuitNode_1.default(test.parent);
        // terminate all finished suites up the test structrure
        while (suite !== undefined && suite.tests.every(function (t) { return t.status === testNodeStatus_1.default.Finished; }) &&
            suite.suites.every(function (s) { return s.status === testNodeStatus_1.default.Finished; })) {
            this.testStructure.finishSuite(suite);
            if (suite.nativeSuite.parent === undefined)
                suite = undefined;
            else
                suite = new playwrightSuitNode_1.default(suite.nativeSuite.parent);
        }
    };
    PlaywrightJBReporter.prototype.onEnd = function (result) {
        var _this = this;
        if (this.globalErrors.length > 0) {
            process.stderr.write(this.globalErrors.join("\n"), function () {
                _this.testStructure.finishTesting();
            });
        }
        else {
            this.testStructure.finishTesting();
        }
    };
    PlaywrightJBReporter.prototype.onError = function (error) {
        var _a = this.normalizeFailureMessageAndStack(error.message, error.stack), message = _a[0], stack = _a[1];
        this.globalErrors.push(message + stack);
    };
    PlaywrightJBReporter.prototype.buildError = function (result) {
        var _this = this;
        var _a;
        var normalizedErrors = result.errors
            .map(function (error) { return _this.normalizeFailureMessageAndStack(error.message, error.stack); });
        var stack = (_a = normalizedErrors.map(function (value) { return value[1]; }).find(function (value) { return value != null; })) !== null && _a !== void 0 ? _a : "";
        var message = normalizedErrors.map(function (value) { return value[0]; }).join("\n");
        return {
            name: 'Error',
            message: message,
            stack: stack
        };
    };
    PlaywrightJBReporter.prototype.normalizeFailureMessageAndStack = function (message, stack) {
        if (stack != null) {
            if (stack.indexOf(message) === 0) {
                stack = stack.substring(message.length);
            }
            else {
                var newMessage = "Error: " + message;
                if (stack.indexOf(newMessage) === 0) {
                    stack = stack.substring(newMessage.length);
                    message = newMessage;
                }
            }
        }
        if (message != null) {
            message = message.replace(ansiRegex, '');
        }
        return [message, stack];
    };
    return PlaywrightJBReporter;
}());
module.exports = PlaywrightJBReporter;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGxheXdyaWdodFJlcG9ydGVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vc3JjL3BsYXl3cmlnaHQvcGxheXdyaWdodFJlcG9ydGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQSwyREFBcUQ7QUFDckQsMkRBQXFEO0FBQ3JELHFFQUErRDtBQUMvRCx5REFBbUQ7QUFHbkQsSUFBTSxnQkFBZ0IsR0FBRztJQUN2Qiw4SEFBOEg7SUFDOUgsMERBQTBEO0NBQzNELENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBRVosSUFBTSxTQUFTLEdBQUcsSUFBSSxNQUFNLENBQUMsZ0JBQWdCLEVBQUUsR0FBRyxDQUFDLENBQUM7QUFFcEQ7SUFBQTtRQUVtQixrQkFBYSxHQUFHLElBQUksaUNBQXVCLEVBQUUsQ0FBQztRQUM5QyxpQkFBWSxHQUFrQixFQUFFLENBQUM7SUEyR3BELENBQUM7SUF6R0MsNENBQWEsR0FBYjtRQUNFLE9BQU8sSUFBSSxDQUFBO0lBQ2IsQ0FBQztJQUVELHNDQUFPLEdBQVAsVUFBUSxNQUFrQixFQUFFLEtBQVk7UUFDdEMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsSUFBSSw0QkFBa0IsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFBO1FBQzlELE9BQU87UUFDUCxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxJQUFJLDRCQUFrQixDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUE7SUFDOUQsQ0FBQztJQUVELDZEQUE2RDtJQUM3RCwwQ0FBVyxHQUFYLFVBQVksSUFBYyxFQUFFLE1BQWtCO1FBQTlDLGlCQW1CQztRQWxCQyxJQUFJLEtBQUssR0FBbUMsSUFBSSw0QkFBa0IsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUE7UUFDL0UsSUFBSSxhQUFhLEdBQXlCLEVBQUUsQ0FBQTtRQUU1QyxPQUFPLEtBQUssS0FBSyxTQUFTLElBQUksS0FBSyxDQUFDLE1BQU0sS0FBSyx3QkFBYyxDQUFDLFVBQVUsRUFBRTtZQUN4RSxhQUFhLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFBO1lBQ3pCLElBQUksS0FBSyxDQUFDLFdBQVcsQ0FBQyxNQUFNLEtBQUssU0FBUztnQkFBRSxLQUFLLEdBQUcsU0FBUyxDQUFBOztnQkFDeEQsS0FBSyxHQUFHLElBQUksNEJBQWtCLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQTtTQUM5RDtRQUVELGFBQWEsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxPQUFPLENBQUMsVUFBQyxLQUF5QjtZQUN4RCxLQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQTtRQUN0QyxDQUFDLENBQUMsQ0FBQTtRQUVGLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLElBQUksNEJBQWtCLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQTtRQUUxRCxJQUFJLElBQUksQ0FBQyxjQUFjLElBQUksU0FBUyxFQUFFO1lBQ3BDLElBQUksQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLElBQUksNEJBQWtCLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQTtTQUM1RDtJQUNILENBQUM7SUFFRCwwQ0FBVyxHQUFYLFVBQVksSUFBYyxFQUFFLE1BQWtCLEVBQUUsSUFBYztRQUM1RCxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQTtJQUNwQyxDQUFDO0lBRUQsd0NBQVMsR0FBVCxVQUFVLElBQWMsRUFBRSxNQUFrQixFQUFFLElBQWM7UUFDMUQsSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUE7SUFDckMsQ0FBQztJQUVELHdDQUFTLEdBQVQsVUFBVSxJQUFjLEVBQUUsTUFBa0I7UUFDMUMseUhBQXlIO1FBQ3pILElBQUksTUFBTSxDQUFDLE1BQU0sSUFBSSxhQUFhO1lBQUUsT0FBTztRQUUzQyxJQUFNLEtBQUssR0FBVSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsSUFBSSxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO1FBQ3ZGLElBQUksQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLElBQUksNEJBQWtCLENBQUMsSUFBSSxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUE7UUFFbEUsSUFBSSxLQUFLLEdBQW1DLElBQUksNEJBQWtCLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFBO1FBQy9FLHVEQUF1RDtRQUN2RCxPQUFPLEtBQUssS0FBSyxTQUFTLElBQUksS0FBSyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsVUFBQyxDQUFxQixJQUFLLE9BQUEsQ0FBQyxDQUFDLE1BQU0sS0FBSyx3QkFBYyxDQUFDLFFBQVEsRUFBcEMsQ0FBb0MsQ0FBQztZQUNoSCxLQUFLLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxVQUFDLENBQXFCLElBQUssT0FBQSxDQUFDLENBQUMsTUFBTSxLQUFLLHdCQUFjLENBQUMsUUFBUSxFQUFwQyxDQUFvQyxDQUFDLEVBQUU7WUFDbkYsSUFBSSxDQUFDLGFBQWEsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUE7WUFDckMsSUFBSSxLQUFLLENBQUMsV0FBVyxDQUFDLE1BQU0sS0FBSyxTQUFTO2dCQUFFLEtBQUssR0FBRyxTQUFTLENBQUE7O2dCQUN4RCxLQUFLLEdBQUcsSUFBSSw0QkFBa0IsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFBO1NBQzlEO0lBQ0gsQ0FBQztJQUVELG9DQUFLLEdBQUwsVUFBTSxNQUFrQjtRQUF4QixpQkFTQztRQVJDLElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO1lBQ2hDLE9BQU8sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO2dCQUNqRCxLQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsRUFBRSxDQUFBO1lBQ3BDLENBQUMsQ0FBQyxDQUFDO1NBQ0o7YUFDSTtZQUNILElBQUksQ0FBQyxhQUFhLENBQUMsYUFBYSxFQUFFLENBQUE7U0FDbkM7SUFDSCxDQUFDO0lBRUQsc0NBQU8sR0FBUCxVQUFRLEtBQWdCO1FBQ2hCLElBQUEsS0FBbUIsSUFBSSxDQUFDLCtCQUErQixDQUFDLEtBQUssQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLEtBQUssQ0FBQyxFQUFsRixPQUFPLFFBQUEsRUFBRSxLQUFLLFFBQW9FLENBQUE7UUFDekYsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQyxDQUFBO0lBQ3pDLENBQUM7SUFFTyx5Q0FBVSxHQUFsQixVQUFtQixNQUFrQjtRQUFyQyxpQkFZQzs7UUFYQyxJQUFNLGdCQUFnQixHQUFHLE1BQU0sQ0FBQyxNQUFNO2FBQ25DLEdBQUcsQ0FBQyxVQUFDLEtBQVksSUFBSyxPQUFBLEtBQUksQ0FBQywrQkFBK0IsQ0FBQyxLQUFLLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxLQUFLLENBQUMsRUFBaEUsQ0FBZ0UsQ0FBQyxDQUFBO1FBRTFGLElBQU0sS0FBSyxHQUFHLE1BQUEsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLFVBQUEsS0FBSyxJQUFJLE9BQUEsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFSLENBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFBLEtBQUssSUFBSSxPQUFBLEtBQUssSUFBSSxJQUFJLEVBQWIsQ0FBYSxDQUFDLG1DQUFJLEVBQUUsQ0FBQTtRQUN4RixJQUFNLE9BQU8sR0FBRyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsVUFBQSxLQUFLLElBQUksT0FBQSxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQVIsQ0FBUSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFBO1FBRWxFLE9BQWM7WUFDWixJQUFJLEVBQUUsT0FBTztZQUNiLE9BQU8sRUFBRSxPQUFPO1lBQ2hCLEtBQUssRUFBRSxLQUFLO1NBQ2IsQ0FBQTtJQUNILENBQUM7SUFFTyw4REFBK0IsR0FBdkMsVUFBd0MsT0FBaUIsRUFBRSxLQUFlO1FBQ3hFLElBQUksS0FBSyxJQUFJLElBQUksRUFBRTtZQUNqQixJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxFQUFFO2dCQUNoQyxLQUFLLEdBQUcsS0FBSyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7YUFDekM7aUJBQ0k7Z0JBQ0gsSUFBTSxVQUFVLEdBQUcsU0FBUyxHQUFHLE9BQU8sQ0FBQztnQkFDdkMsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsRUFBRTtvQkFDbkMsS0FBSyxHQUFHLEtBQUssQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUMzQyxPQUFPLEdBQUcsVUFBVSxDQUFDO2lCQUN0QjthQUNGO1NBQ0Y7UUFDRCxJQUFJLE9BQU8sSUFBSSxJQUFJLEVBQUU7WUFDbkIsT0FBTyxHQUFHLE9BQU8sQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFLEVBQUUsQ0FBQyxDQUFDO1NBQzFDO1FBQ0QsT0FBTyxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsQ0FBQTtJQUN6QixDQUFDO0lBQ0gsMkJBQUM7QUFBRCxDQUFDLEFBOUdELElBOEdDO0FBRUQsaUJBQVMsb0JBQW9CLENBQUEiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUGxheXdyaWdodFN1aXROb2RlIGZyb20gXCIuL3BsYXl3cmlnaHRTdWl0Tm9kZVwiXG5pbXBvcnQgUGxheXdyaWdodFRlc3ROb2RlIGZyb20gXCIuL3BsYXl3cmlnaHRUZXN0Tm9kZVwiXG5pbXBvcnQgUGxheXdyaWdodFRlc3RTdHJ1Y3R1cmUgZnJvbSBcIi4vcGxheXdyaWdodFRlc3RTdHJ1Y3R1cmVcIlxuaW1wb3J0IFRlc3ROb2RlU3RhdHVzIGZyb20gXCIuLi9jb3JlL3Rlc3ROb2RlU3RhdHVzXCJcbmltcG9ydCB7RnVsbENvbmZpZywgRnVsbFJlc3VsdCwgUmVwb3J0ZXIsIFN1aXRlLCBUZXN0Q2FzZSwgVGVzdEVycm9yLCBUZXN0UmVzdWx0LCBUZXN0U3RlcH0gZnJvbSBcIkBwbGF5d3JpZ2h0L3Rlc3QvcmVwb3J0ZXJcIjtcblxuY29uc3QgYW5zaVJlZ2V4UGF0dGVybiA9IFtcbiAgJ1tcXFxcdTAwMUJcXFxcdTAwOUJdW1tcXFxcXSgpIzs/XSooPzooPzooPzooPzo7Wy1hLXpBLVpcXFxcZFxcXFwvIyYuOj0/JUB+X10rKSp8W2EtekEtWlxcXFxkXSsoPzo7Wy1hLXpBLVpcXFxcZFxcXFwvIyYuOj0/JUB+X10qKSopP1xcXFx1MDAwNyknLFxuICAnKD86KD86XFxcXGR7MSw0fSg/OjtcXFxcZHswLDR9KSopP1tcXFxcZEEtUFItVFpjZi1udHFyeT0+PH5dKSknXG5dLmpvaW4oJ3wnKTtcblxuY29uc3QgYW5zaVJlZ2V4ID0gbmV3IFJlZ0V4cChhbnNpUmVnZXhQYXR0ZXJuLCAnZycpO1xuXG5jbGFzcyBQbGF5d3JpZ2h0SkJSZXBvcnRlciBpbXBsZW1lbnRzIFJlcG9ydGVyIHtcblxuICBwcml2YXRlIHJlYWRvbmx5IHRlc3RTdHJ1Y3R1cmUgPSBuZXcgUGxheXdyaWdodFRlc3RTdHJ1Y3R1cmUoKTtcbiAgcHJpdmF0ZSByZWFkb25seSBnbG9iYWxFcnJvcnM6IEFycmF5PFN0cmluZz4gPSBbXTtcblxuICBwcmludHNUb1N0ZGlvKCk6IGJvb2xlYW4ge1xuICAgIHJldHVybiB0cnVlXG4gIH1cblxuICBvbkJlZ2luKGNvbmZpZzogRnVsbENvbmZpZywgc3VpdGU6IFN1aXRlKSB7XG4gICAgdGhpcy50ZXN0U3RydWN0dXJlLnN0YXJ0VGVzdGluZyhuZXcgUGxheXdyaWdodFN1aXROb2RlKHN1aXRlKSlcbiAgICAvLyByb290XG4gICAgdGhpcy50ZXN0U3RydWN0dXJlLnN0YXJ0U3VpdGUobmV3IFBsYXl3cmlnaHRTdWl0Tm9kZShzdWl0ZSkpXG4gIH1cblxuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLXVudXNlZC12YXJzXG4gIG9uVGVzdEJlZ2luKHRlc3Q6IFRlc3RDYXNlLCByZXN1bHQ6IFRlc3RSZXN1bHQpOiB2b2lkIHtcbiAgICBsZXQgc3VpdGU6IFBsYXl3cmlnaHRTdWl0Tm9kZSB8IHVuZGVmaW5lZCA9IG5ldyBQbGF5d3JpZ2h0U3VpdE5vZGUodGVzdC5wYXJlbnQpXG4gICAgbGV0IHN1aXRlc1RvU3RhcnQ6IFBsYXl3cmlnaHRTdWl0Tm9kZVtdID0gW11cblxuICAgIHdoaWxlIChzdWl0ZSAhPT0gdW5kZWZpbmVkICYmIHN1aXRlLnN0YXR1cyA9PT0gVGVzdE5vZGVTdGF0dXMuTm90U3RhcnRlZCkge1xuICAgICAgc3VpdGVzVG9TdGFydC5wdXNoKHN1aXRlKVxuICAgICAgaWYgKHN1aXRlLm5hdGl2ZVN1aXRlLnBhcmVudCA9PT0gdW5kZWZpbmVkKSBzdWl0ZSA9IHVuZGVmaW5lZFxuICAgICAgZWxzZSBzdWl0ZSA9IG5ldyBQbGF5d3JpZ2h0U3VpdE5vZGUoc3VpdGUubmF0aXZlU3VpdGUucGFyZW50KVxuICAgIH1cblxuICAgIHN1aXRlc1RvU3RhcnQucmV2ZXJzZSgpLmZvckVhY2goKHN1aXRlOiBQbGF5d3JpZ2h0U3VpdE5vZGUpID0+IHtcbiAgICAgIHRoaXMudGVzdFN0cnVjdHVyZS5zdGFydFN1aXRlKHN1aXRlKVxuICAgIH0pXG5cbiAgICB0aGlzLnRlc3RTdHJ1Y3R1cmUuc3RhcnRUZXN0KG5ldyBQbGF5d3JpZ2h0VGVzdE5vZGUodGVzdCkpXG5cbiAgICBpZiAodGVzdC5leHBlY3RlZFN0YXR1cyA9PSAnc2tpcHBlZCcpIHtcbiAgICAgIHRoaXMudGVzdFN0cnVjdHVyZS5pZ25vcmVUZXN0KG5ldyBQbGF5d3JpZ2h0VGVzdE5vZGUodGVzdCkpXG4gICAgfVxuICB9XG5cbiAgb25TdGVwQmVnaW4odGVzdDogVGVzdENhc2UsIHJlc3VsdDogVGVzdFJlc3VsdCwgc3RlcDogVGVzdFN0ZXApIHtcbiAgICB0aGlzLnRlc3RTdHJ1Y3R1cmUuc3RhcnRTdGVwKHN0ZXApXG4gIH1cblxuICBvblN0ZXBFbmQodGVzdDogVGVzdENhc2UsIHJlc3VsdDogVGVzdFJlc3VsdCwgc3RlcDogVGVzdFN0ZXApIHtcbiAgICB0aGlzLnRlc3RTdHJ1Y3R1cmUuZmluaXNoU3RlcChzdGVwKVxuICB9XG5cbiAgb25UZXN0RW5kKHRlc3Q6IFRlc3RDYXNlLCByZXN1bHQ6IFRlc3RSZXN1bHQpIHtcbiAgICAvLyBJZiB0aGUgdGVzdCBzdGF0dXMgaXMgaW50ZXJydXB0ZWQsIGRvbid0IGhhdmUgdG8gZmluaXNoIHRlc3QgaW4gc3RydWN0dXJlLCBpdCB3aWxsIGJlIG1hcmtlZCBhcyBpbnRlcnJ1cHRlZCBieSBkZWZhdWx0XG4gICAgaWYgKHJlc3VsdC5zdGF0dXMgPT0gXCJpbnRlcnJ1cHRlZFwiKSByZXR1cm47XG5cbiAgICBjb25zdCBlcnJvcjogRXJyb3IgPSAodGVzdC5vdXRjb21lKCkgPT0gXCJ1bmV4cGVjdGVkXCIpID8gdGhpcy5idWlsZEVycm9yKHJlc3VsdCkgOiBudWxsO1xuICAgIHRoaXMudGVzdFN0cnVjdHVyZS5maW5pc2hUZXN0KG5ldyBQbGF5d3JpZ2h0VGVzdE5vZGUodGVzdCksIGVycm9yKVxuXG4gICAgbGV0IHN1aXRlOiBQbGF5d3JpZ2h0U3VpdE5vZGUgfCB1bmRlZmluZWQgPSBuZXcgUGxheXdyaWdodFN1aXROb2RlKHRlc3QucGFyZW50KVxuICAgIC8vIHRlcm1pbmF0ZSBhbGwgZmluaXNoZWQgc3VpdGVzIHVwIHRoZSB0ZXN0IHN0cnVjdHJ1cmVcbiAgICB3aGlsZSAoc3VpdGUgIT09IHVuZGVmaW5lZCAmJiBzdWl0ZS50ZXN0cy5ldmVyeSgodDogUGxheXdyaWdodFRlc3ROb2RlKSA9PiB0LnN0YXR1cyA9PT0gVGVzdE5vZGVTdGF0dXMuRmluaXNoZWQpICYmXG4gICAgc3VpdGUuc3VpdGVzLmV2ZXJ5KChzOiBQbGF5d3JpZ2h0U3VpdE5vZGUpID0+IHMuc3RhdHVzID09PSBUZXN0Tm9kZVN0YXR1cy5GaW5pc2hlZCkpIHtcbiAgICAgIHRoaXMudGVzdFN0cnVjdHVyZS5maW5pc2hTdWl0ZShzdWl0ZSlcbiAgICAgIGlmIChzdWl0ZS5uYXRpdmVTdWl0ZS5wYXJlbnQgPT09IHVuZGVmaW5lZCkgc3VpdGUgPSB1bmRlZmluZWRcbiAgICAgIGVsc2Ugc3VpdGUgPSBuZXcgUGxheXdyaWdodFN1aXROb2RlKHN1aXRlLm5hdGl2ZVN1aXRlLnBhcmVudClcbiAgICB9XG4gIH1cblxuICBvbkVuZChyZXN1bHQ6IEZ1bGxSZXN1bHQpIHtcbiAgICBpZiAodGhpcy5nbG9iYWxFcnJvcnMubGVuZ3RoID4gMCkge1xuICAgICAgcHJvY2Vzcy5zdGRlcnIud3JpdGUodGhpcy5nbG9iYWxFcnJvcnMuam9pbihcIlxcblwiKSwgKCkgPT4ge1xuICAgICAgICB0aGlzLnRlc3RTdHJ1Y3R1cmUuZmluaXNoVGVzdGluZygpXG4gICAgICB9KTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICB0aGlzLnRlc3RTdHJ1Y3R1cmUuZmluaXNoVGVzdGluZygpXG4gICAgfVxuICB9XG5cbiAgb25FcnJvcihlcnJvcjogVGVzdEVycm9yKSB7XG4gICAgY29uc3QgW21lc3NhZ2UsIHN0YWNrXSA9IHRoaXMubm9ybWFsaXplRmFpbHVyZU1lc3NhZ2VBbmRTdGFjayhlcnJvci5tZXNzYWdlLCBlcnJvci5zdGFjaylcbiAgICB0aGlzLmdsb2JhbEVycm9ycy5wdXNoKG1lc3NhZ2UgKyBzdGFjaylcbiAgfVxuXG4gIHByaXZhdGUgYnVpbGRFcnJvcihyZXN1bHQ6IFRlc3RSZXN1bHQpOiBFcnJvciB7XG4gICAgY29uc3Qgbm9ybWFsaXplZEVycm9ycyA9IHJlc3VsdC5lcnJvcnNcbiAgICAgIC5tYXAoKGVycm9yOiBFcnJvcikgPT4gdGhpcy5ub3JtYWxpemVGYWlsdXJlTWVzc2FnZUFuZFN0YWNrKGVycm9yLm1lc3NhZ2UsIGVycm9yLnN0YWNrKSlcblxuICAgIGNvbnN0IHN0YWNrID0gbm9ybWFsaXplZEVycm9ycy5tYXAodmFsdWUgPT4gdmFsdWVbMV0pLmZpbmQodmFsdWUgPT4gdmFsdWUgIT0gbnVsbCkgPz8gXCJcIlxuICAgIGNvbnN0IG1lc3NhZ2UgPSBub3JtYWxpemVkRXJyb3JzLm1hcCh2YWx1ZSA9PiB2YWx1ZVswXSkuam9pbihcIlxcblwiKVxuXG4gICAgcmV0dXJuIDxFcnJvcj57XG4gICAgICBuYW1lOiAnRXJyb3InLCAvL1RPRE86IENsYXJpZnkgdGhlIG5hbWVcbiAgICAgIG1lc3NhZ2U6IG1lc3NhZ2UsXG4gICAgICBzdGFjazogc3RhY2tcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIG5vcm1hbGl6ZUZhaWx1cmVNZXNzYWdlQW5kU3RhY2sobWVzc2FnZSA/OiBzdHJpbmcsIHN0YWNrID86IHN0cmluZyk6IFtzdHJpbmcsIHN0cmluZ10ge1xuICAgIGlmIChzdGFjayAhPSBudWxsKSB7XG4gICAgICBpZiAoc3RhY2suaW5kZXhPZihtZXNzYWdlKSA9PT0gMCkge1xuICAgICAgICBzdGFjayA9IHN0YWNrLnN1YnN0cmluZyhtZXNzYWdlLmxlbmd0aCk7XG4gICAgICB9XG4gICAgICBlbHNlIHtcbiAgICAgICAgY29uc3QgbmV3TWVzc2FnZSA9IFwiRXJyb3I6IFwiICsgbWVzc2FnZTtcbiAgICAgICAgaWYgKHN0YWNrLmluZGV4T2YobmV3TWVzc2FnZSkgPT09IDApIHtcbiAgICAgICAgICBzdGFjayA9IHN0YWNrLnN1YnN0cmluZyhuZXdNZXNzYWdlLmxlbmd0aCk7XG4gICAgICAgICAgbWVzc2FnZSA9IG5ld01lc3NhZ2U7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKG1lc3NhZ2UgIT0gbnVsbCkge1xuICAgICAgbWVzc2FnZSA9IG1lc3NhZ2UucmVwbGFjZShhbnNpUmVnZXgsICcnKTtcbiAgICB9XG4gICAgcmV0dXJuIFttZXNzYWdlLCBzdGFja11cbiAgfVxufVxuXG5leHBvcnQgPSBQbGF5d3JpZ2h0SkJSZXBvcnRlclxuIl19