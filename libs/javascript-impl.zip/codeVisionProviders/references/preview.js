class MyClass {
  myMethod() {}
}

let a = new MyClass()
a.myMethod()
a.myMethod()
