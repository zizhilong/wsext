class MyButton { }
class AnimatedButton extends MyButton { }
