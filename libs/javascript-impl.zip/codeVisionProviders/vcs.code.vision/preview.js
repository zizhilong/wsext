class MyClass {
  myMethod() {}
}