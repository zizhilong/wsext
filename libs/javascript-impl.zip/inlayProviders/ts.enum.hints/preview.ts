enum Item {
 First/*/*<#  = 0 #>*/*/,
 Second = 5,
 Third/*/*<#  = 6 #>*/*/
}