class TestClass {
    m(p: (t: string) => void)/*<# : number #>*/ {
        return 5;
    }
}

function functionA()/*<# : string #>*/ {
    return "a"
}

const functionB = ()/*<# : [number, number, number] #>*/ => [1, 2, 3];