class TestClass {
    m(p: (t: string) => void)/*<# : number #>*/ {
        return 5;
    }
}

new TestClass().m(p/*<# : string #>*/ => {})