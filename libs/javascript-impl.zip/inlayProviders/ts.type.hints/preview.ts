var z/*<# : number #>*/ = 3;

function test()/*<# : string #>*/ { return "a" }

class Clazz {
  x/*<# : number #>*/ = 5;
  m(p: (t: string) => void)/*<# : number #>*/ {
    return 5;
  }
}

new Clazz().m(p/*<# : string #>*/ => {})
new Clazz().m((p/*<# : string #>*/)/*<# : void #>*/ => {})