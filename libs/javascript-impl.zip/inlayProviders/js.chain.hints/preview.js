var z = [1, 2, 3];

z
    .map(function(e) { return String(e) })/*/*<# string[] #>*/*/
    .map(function(e) { return Number(e) })/*/*<# number[] #>*/*/
    .map(function(e) { return String(e) })/*/*<# string[] #>*/*/
    .map(function(e) { return Number(e) });