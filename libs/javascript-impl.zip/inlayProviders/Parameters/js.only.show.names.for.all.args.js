/**
 * @param {object} param Object to add descriptors to
 */
function test(param) {}

let data = {}

test(data)