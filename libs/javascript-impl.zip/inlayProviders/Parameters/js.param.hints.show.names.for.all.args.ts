function test(param: number[]) {}

let data = [1, 2, 3]
test(data)