const name = "WebStorm"

const greet = name => `Hello, ${name}`

const capitalize = str => str.toUpperCase()
const loudGreeting = name
    |> greet
    |> capitalize