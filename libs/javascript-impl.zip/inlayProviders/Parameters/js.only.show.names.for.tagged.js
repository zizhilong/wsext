let person = 'WebStorm';

function myTag(strings, person, age) {
}

let output = myTag`That ${ person } is ${ 11 }.`;