let person = 'WebStorm';

function myTag(strings, person: string, age: number) {}

let output = myTag`That ${person} is ${11}.`;