var z/*/*<# : number #>*/*/ = 3;
function test()/*/*<# : string #>*/*/ { return "a" }
/**
* @param {function(number): string} p
*/
function x(p) {}
x(p/*/*<# : number #>*/*/ => "a")
x((p/*/*<# : number #>*/*/)/*/*<# : string #>*/*/ => "a")