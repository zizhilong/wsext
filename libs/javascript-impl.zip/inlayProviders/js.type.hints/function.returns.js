function functionA()/*<# : string #>*/ {
  return "a"
}

const functionB = ()/*<# : number[] #>*/ => [1, 2, 3];