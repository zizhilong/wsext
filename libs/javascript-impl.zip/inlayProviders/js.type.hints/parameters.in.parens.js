/**
 * @param {function(number): string} p
 */
function test(p) {
}

test((p/*<# : number #>*/)/*<# : string #>*/ => "a")