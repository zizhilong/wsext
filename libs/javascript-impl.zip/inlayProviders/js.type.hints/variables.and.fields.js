const a/*<# : number #>*/ = 22;
let b/*<# : string #>*/ = 'Hello World';
var z/*<# : number[] #>*/ = [1, 2, 3];

class TestClass {
  x/*<# : number #>*/ = 5;
}