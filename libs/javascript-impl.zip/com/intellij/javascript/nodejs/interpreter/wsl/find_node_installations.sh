#!/bin/sh

printNode()
{
  if [ -f "$1" ]; then
    echo "\nnode_path:$1\n"
  fi
}


NVM_ROOT="$NVM_DIR"
if [ -z "$NVM_ROOT" ]; then
  NVM_ROOT="$HOME/.nvm"
fi

if [ -d "$NVM_ROOT" ]; then
  for line in $(ls --almost-all -1 "$NVM_ROOT/versions/node"); do
    printNode "$NVM_ROOT/versions/node/$line/bin/node"
  done
fi

printNode "$(which node)"

echo "$PATH"